import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OpenBrowser {

public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		String url = "https://demo.nopcommerce.com/";
		driver.get(url);
		driver.manage().window().maximize();
		
		// first test SignUP
		driver.findElement(By.className("ico-register")).click();
		driver.findElement(By.className("buttons")).click();
		driver.findElement(By.id("gender-male")).click();
		driver.findElement(By.id("FirstName")).sendKeys("automation");
		driver.findElement(By.id("LastName")).sendKeys("tester");
		// static AgeList
		Select day= new Select (driver.findElement(By.name("DateOfBirthDay")));
		day.selectByValue("2");
		Thread.sleep(2000);
		Select month = new Select (driver.findElement(By.name("DateOfBirthMonth")));
		month.selectByValue("3");
		Thread.sleep(2000);
		Select year = new Select (driver.findElement(By.name("DateOfBirthYear")));
		year.selectByValue("1996");
		Thread.sleep(2000);
		driver.findElement(By.id("Email")).sendKeys( "test@example.com");
		driver.findElement(By.id("Password")).sendKeys("P@ssw0rd");
		driver.findElement(By.id("ConfirmPassword")).sendKeys("P@ssw0rd");
		driver.findElement(By.id("register-button")).click();
		
		// second test SignIN right data
		
//		driver.findElement(By.className("ico-login")).click();
//		driver.findElement(By.id("Email")).sendKeys("test@example.com");
//		driver.findElement(By.id("Password")).sendKeys("P@ssw0rd");
//		driver.findElement(By.className("buttons")).click();
		// SignIN wrong data
//		driver.findElement(By.className("ico-login")).click();
//		driver.findElement(By.id("Email")).sendKeys("test22@example.com");
//		driver.findElement(By.id("Password")).sendKeys("P@ssw0rd");
//		driver.findElement(By.className("buttons")).click();
//		
		
		//Loged user search any product
//		driver.findElement(By.id("small-searchterms")).sendKeys("HTC");
//		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
//		//adding proudcts to cart
//		driver.findElement(By.xpath("//button[@type=\"button\"]")).click();
//		driver.findElement(By.className("cart-label")).click();
//		 adding item from computers eli f elawl 
//		driver.findElement(By.cssSelector("a[href=\"/computers\"]")).click();
//		driver.findElement(By.cssSelector("a[href=\"/desktops\"]")).click();
//		driver.findElement(By.cssSelector("a[title=\"Show products in category Desktops\"]")).click();
//		//adding to wishlist
//		driver.findElement(By.id("small-searchterms")).sendKeys("HTC");
//		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
//		driver.findElement(By.xpath("//button[@title=\"Add to wishlist\"]")).click();
//		driver.findElement(By.className("wishlist-label")).click();
//		// passsword reset'
//		driver.findElement(By.className("ico-login")).click();
//		driver.findElement(By.className("forgot-password")).click();
//		driver.findElement(By.id("Email")).sendKeys("test@example.com");
//		driver.findElement(By.className("button-1 password-recovery-button")).click();
		
		
		Thread.sleep(3000);
		driver.close();
}
	

////	WebDriver driver = null;
////	@BeforeTest
////	public void open () {
////		WebDriverManager.chromedriver().setup();
////		WebDriver driver = new ChromeDriver();
////		String url = "https://demo.nopcommerce.com/login?returnUrl=%2F";
////		driver.get(url);
////		driver.manage().window().maximize();
////		
////	}
////	@Test
////	public void valid1 () {
//		driver.findElement(By.className("ico-login")).click();
//		
//	}
//@AfterTest
//public void close () {
//	driver.close();
}


